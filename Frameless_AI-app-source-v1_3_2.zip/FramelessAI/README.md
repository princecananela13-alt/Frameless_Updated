# Frameless_AI app (WebUI host + in-game panel), package com.frameless.ai

Build: upload folder to GitHub -> Actions -> "Build APK" -> artifact FramelessAI.apk (or Android Studio > Build APK).
Install: uninstall the old Frameless_AI app first (different signing key), install this one, allow root.
Then flash module v1.3.1 and reboot. WebUI > Games > In-game panel.


## Tweaks update v1.3.2
Added gaming quick presets (Competitive/FPS, Balanced, Low heat), animation scale shortcuts, cache-drop shortcut, and profile re-apply shortcut in the Tweaks page. These invoke the existing allow-listed module commands; device support varies.
